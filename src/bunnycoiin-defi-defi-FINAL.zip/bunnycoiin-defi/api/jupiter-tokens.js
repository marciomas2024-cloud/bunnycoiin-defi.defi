export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  const apiKey = process.env.JUPITER_API_KEY;
  if (!apiKey) return res.status(500).json({ error: 'JUPITER_API_KEY não configurada no servidor.' });

  const query = req.query.query || '';
  const jupiterUrl = `https://api.jup.ag/tokens/v1/search?query=${encodeURIComponent(query)}`;

  try {
    const upstream = await fetch(jupiterUrl, {
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
      },
    });
    const data = await upstream.json();
    return res.status(upstream.status).json(data);
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
}
